<?php

echo json_encode(array("c" => $_GET['id']));